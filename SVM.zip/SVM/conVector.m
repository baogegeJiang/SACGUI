function [x,xd]= conVector(index,data)
xd=conXD(index,data);
x=conX(index,data);

